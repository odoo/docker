# Copyright 2020 initOS GmbH.
from . import test_ir_config_parameter
